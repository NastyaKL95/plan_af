<?php

return [
    'db' => [
        'host' => 'MySQL-8.4',
        'port' => 3306,
        'dbname' => 'konk',
        'user' => 'root',
        'password' => '',
    ],
    /* БД и доступ — как у основного приложения; при необходимости замените dbname на базу, где лежит dat_peoples. */
    'external_auth' => [
        'enabled' => false,
        'host' => '192.168.2.5',
        'port' => 3306,
        'dbname' => 'c1_zabedu',
        'user' => 'c1do',
        'password' => 'Wtynhbyajhvfnbpfwbbdo1',
        /* Явная база в имени таблицы, если в подключении по умолчанию оказывается не та схема */
        'table' => 'dat_peoples',
        'email_column' => 'login',
        'password_hash_column' => 'passwd',
        'password_format' => 'plain',
        'login_page_note' => 'Вход по логину и паролю из таблицы dat_peoples (как в старой системе).',
    ],
    'app' => [
        'name' => 'IRO PHP',
    ],
];
