<?php
declare(strict_types=1);

/**
 * Локальная конфигурация БД и политик (создано мастером установки install/).
 * Не публикуйте этот файл в открытый репозиторий.
 */
return [
    'host' => 'localhost',
    'port' => 3306,
    'database' => 'c1_af',
    'user' => 'c1_af',
    'password' => 'Ka9sRgh)',
    'charset' => 'utf8mb4',
    'runtime_migrations' => false,
    'registration_open' => true,
    'session_cookie_lifetime' => 0,
    'session_cookie_secure' => true,
    'session_cookie_samesite' => 'Lax',
];
