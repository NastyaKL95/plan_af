# Выкладка в продакшен (Аудиторный фонд)

Краткий чеклист. Подробности в комментариях к `config/database.local.example.php`.

## 1. База и конфиг

- Выполнить скрипты из `sql/` на целевой MySQL **в порядке номеров** в имени файла.
- Скопировать `config/database.local.example.php` → `config/database.local.php`, задать `host`, `database`, `user`, `password`.
- **`runtime_migrations` → `false`** после того, как схема приведена к актуальному виду (без `CREATE`/`ALTER` на каждый HTTP-запрос).
- **`registration_open` → `false`**, если открытая регистрация не нужна.
- **`production` → `true`** — скрыть вывод ошибок PHP в HTML (или задать в окружении **`AUDIT_FUND_PRODUCTION=true`**).
- По **HTTPS**: **`session_cookie_secure` → `true`** (или оставить `null` — включится автоматически при HTTPS).

## 2. PHP и веб-сервер

- Версия PHP **≥ 8.0**, расширения: **pdo_mysql**, **mbstring**, **json**.
- В `php.ini` на проде: `display_errors=Off`, `log_errors=On`, корректный `error_log`.
- При необходимости: `composer install --no-dev --optimize-autoloader` в корне проекта.

### Apache

- Включены модули, чтобы срабатывали **`.htaccess`** в `config/`, `includes/`, `storage/`, `sql/`.
- После установки: переименовать **`install/.htaccess.production`** → **`install/.htaccess`**, чтобы закрыть каталог установки (перед повторным мастером — временно убрать).

### Nginx

- Аналог `Require all denied` — `location` с `deny all` для `config/`, `includes/`, `storage/`, при необходимости `install/`.
- Пример переменной окружения: `fastcgi_param AUDIT_FUND_PRODUCTION true;` (если используете FPM).

## 3. Права и секреты

- Каталоги **`storage/login_rate_limit`** и **`storage/register_rate_limit`** — **запись** для пользователя PHP.
- Файл **`config/database.local.php`** не попадать в публичный репозиторий (уже в `.gitignore`).

## 4. Мастер установки

- В **`includes/install_lib.php`** функция **`audit_fund_install_wizard_enabled()`** на проде обычно **`false`** (уже по умолчанию).
- Каталог **`install/`** после ввода в эксплуатацию лучше закрыть `.htaccess` или удалить с сервера.

## 5. Резервное копирование

- Регулярный дамп БД и при необходимости копия `config/database.local.php` вне сервера (безопасное хранение).

## 6. Проверка после выкладки

- Вход под администратором, расписание, заявка, отчёты (роль staff).
- Убедиться, что по прямому URL нельзя скачать файлы из `config/` и `includes/` (ожидается **403**).
